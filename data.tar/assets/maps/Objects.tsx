<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Objects" tilewidth="12" tileheight="12" tilecount="20" columns="4">
 <image source="../graphics/objectsheet.png" width="48" height="60"/>
 <tile id="0" type="Hero"/>
 <tile id="1" type="Coin"/>
 <tile id="2" type="Bell"/>
 <tile id="3" type="Chest"/>
 <tile id="4" type="Lockbox"/>
 <tile id="5" type="Key"/>
 <tile id="6" type="Spring"/>
 <tile id="7" type="Flag"/>
 <tile id="8" type="Ruby"/>
 <tile id="9" type="Cherry"/>
 <tile id="10" type="Banana"/>
 <tile id="11" type="BonusFlag"/>
 <tile id="12" type="Apple"/>
 <tile id="13" type="Watermelon"/>
 <tile id="14" type="Grapes"/>
 <tile id="15" type="Bubble"/>
 <tile id="16" type="Crumbler"/>
</tileset>
