<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="More" tilewidth="12" tileheight="12" tilecount="72" columns="8">
 <image source="../graphics/spritesheet.png" width="96" height="108"/>
 <tile id="24">
  <animation>
   <frame tileid="24" duration="100"/>
   <frame tileid="25" duration="100"/>
   <frame tileid="26" duration="100"/>
   <frame tileid="27" duration="100"/>
  </animation>
 </tile>
</tileset>
