<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Sprites" class="Sprite" tilewidth="12" tileheight="12" tilecount="88" columns="8">
 <image source="../graphics/spritesheet.png" width="96" height="132"/>
 <tile id="0" type="error"/>
 <tile id="52" type="coin_1"/>
 <tile id="53" type="coin_2"/>
 <tile id="54" type="coin_3"/>
 <tile id="55" type="coin_4"/>
 <tile id="80" type="lamp_unlit"/>
 <tile id="81" type="lamp_green"/>
 <tile id="82" type="lamp_amber"/>
 <tile id="83" type="lamp_red"/>
</tileset>
