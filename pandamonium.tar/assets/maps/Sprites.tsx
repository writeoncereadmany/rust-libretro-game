<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Sprites" class="Sprite" tilewidth="12" tileheight="12" tilecount="88" columns="8">
 <image source="../graphics/spritesheet.png" width="96" height="132"/>
 <tile id="80" type="lamp_unlit"/>
 <tile id="81" type="lamp_green"/>
 <tile id="82" type="lamp_amber"/>
 <tile id="83" type="lamp_red"/>
</tileset>
